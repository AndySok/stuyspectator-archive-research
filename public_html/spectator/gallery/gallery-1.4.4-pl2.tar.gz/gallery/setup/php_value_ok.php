<?php /* $Id: php_value_ok.php,v 1.5 2003/07/28 09:49:27 jefmcg Exp $ */ ?>
<?php
// If we include this file it means that the php_value directive in .htaccess 
// was obeyed.
$GALLERY_PHP_VALUE_OK = 1;
?>