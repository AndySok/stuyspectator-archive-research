README.txt

The images and theme contained in this skin cannot be altered or distributed except by 
permission from the original author. The author's information is found in the style.def and 
when possible linked within the wrapper.footer file which you will need to upload or append
to your site to use the Skin.

Pownuke has obtained permission from each of the authors to use their graphics for a 
coordinating Skin for Gallery. Please respect the wishes of the original authors by 
crediting their work. By doing so will enable me to continue to work with the 
original authors to create future coordinating Gallery Skins. 

Thank you,
JoEllen Drazan
aka:JadeDragon
http://pownuke.com/galleryskins